﻿using System;

namespace Try_Catch
{
    class Program
    {
        static void Main(string[] args)
        {
            int contador = 0;
            string linea;

            System.IO.StreamReader file = new System.IO.StreamReader(@"C:\Users\Alvaro\Documents\CENEC 19-20\Entorno de Desarrollo\Final 2º Trimestre\Try Catch\final.txt");
            try
            {
                while ((linea = file.ReadLine()) != null)
                {
                    System.Console.WriteLine(linea);
                    contador++;
                }
                file.Close();
            }
            catch (Exception e)
            {
                file.Close();
                Environment.Exit(99);
            }

            byte[] numeros = new byte[10];
            Boolean correcto = true;

            for (int i = 0; i < numeros.Length; i++)
            {
                while (correcto)
                {
                    try
                    {
                        do
                        {
                            Console.WriteLine("Introduce un numero entre el 1 y 99, por favor ");
                            numeros[i] = byte.Parse(Console.ReadLine());
                            correcto = false;
                        } while (!(numeros[i] < 100 && numeros[i] > 0));
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Numero incorrecto");
                        Console.WriteLine(e);
                        correcto = true;
                    }
                }
                correcto = true;
            }
            Console.WriteLine("El Array ordenado es: ");
            Array.Sort(numeros);

            for (int i = 0; i < numeros.Length; i++)
            {
                Console.WriteLine(numeros[i]);
            }
        }
    }
    }

