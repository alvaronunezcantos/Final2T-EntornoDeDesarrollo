﻿using System;

namespace Operacion_Matematica
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            int numero1, numero2;
            String operacion, linea;
            Console.WriteLine("-- Bienvenido al Programa --");
            Console.WriteLine("Introduzca el primer numero, por favor");
            linea = Console.ReadLine();
            numero1 = int.Parse(linea);
            Console.WriteLine("Introduce otro numero");
            linea = Console.ReadLine();
            numero2 = int.Parse(linea);
            Console.WriteLine("Introduce la operacion");
            operacion = Console.ReadLine();

            if (operacion == "+")
            {
                int resultado = numero1 + numero2;
                Console.WriteLine(numero1 + "+" + numero2 + "=" + resultado);
            }
            if (operacion == "-")
            {
                int resultado = numero1 - numero2;
                Console.WriteLine(numero1 + "-" + numero2 + "=" + resultado);
            }
            if (operacion == "*")
            {
                int resultado = numero1 * numero2;
                Console.WriteLine(numero1 + "*" + numero2 + "=" + resultado);
            }
            if (operacion == "/")
            {
                int resultado = numero1 / numero2;
                Console.WriteLine(numero1 + "/" + numero2 + "=" + resultado);
            }
        }
    }
}
