﻿using System;

namespace Pintando_la_consola
{
    class Program
    {
        protected static int origRow;
        protected static int origCol;

        protected static void WriteAt(ConsoleColor[] colors)
        {
            try
            {
                Random ran = new Random();
                int caracterAleatorio = ran.Next(5);
                char[] caracter = { (char)33, (char)34, (char)35, (char)36, (char)37 };

                int caracterColor = ran.Next(16);

                int caracterColorFondo = ran.Next(16);

                int posX = ran.Next(81);
                int posY = ran.Next(25);

                Console.SetCursorPosition(origCol + posX, origRow + posY);
                Console.ForegroundColor = colors[caracterColor];
                Console.BackgroundColor = colors[caracterColorFondo];
                Console.Write(caracter[caracterAleatorio]);

            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.Clear();
                Console.WriteLine(e.Message);
            }
        }
        public static void Main(string[] args)
        {

            ConsoleColor[] colors = (ConsoleColor[])ConsoleColor.GetValues(typeof(ConsoleColor));

            ConsoleColor currentBackground = Console.BackgroundColor;
            ConsoleColor currentForeground = Console.ForegroundColor;

            origRow = Console.CursorTop;
            origCol = Console.CursorLeft;


            for (int j = 0; j < 3000; j++)
            {
                WriteAt(colors);
            }

            Console.SetCursorPosition(origCol + 81, origRow + 25);
            Console.ResetColor();
        }
    }
}
