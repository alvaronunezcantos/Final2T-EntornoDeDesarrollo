﻿using System;

namespace Condiciones_Compuestas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("-- Bienvenido al programa --");

            string mes;

            Console.Write("Escribe un mes del año: ");

            mes = Console.ReadLine();

            if (mes == "enero" || mes == "febrero" || mes == "marzo")
            {
                Console.Write("Corresponde al primer trimestre");
            }

            else if (mes == "abril" || mes == "mayo" || mes == "junio")
            {
                Console.Write("Corresponde al segundo trimestre");
            }

            else if (mes == "julio" || mes == "agosto" || mes == "septiembre")
            {
                Console.Write("Corresponde al tercer trimestre");
            }

            else if (mes == "octubre" || mes == "noviembre" || mes == "diciembre")
            {
                Console.Write("Corresponde al cuarto trimestre");
            }
            else
            {
                Console.Write("El mes introducido no es valido");
            }
            
        }
    }
}