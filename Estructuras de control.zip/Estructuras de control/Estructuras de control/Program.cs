﻿using System;

namespace Estructuras_de_control
{
    class Program
    {
        static void Main(string[] args)
        {
            int numeroAleatorio;
            int contador = 0;
            int total = 1;

            Console.WriteLine("-- Bienvenido al programa --");
            Console.WriteLine("Introduce cuantos numeros aleatorios quieres, por favor ");
            numeroAleatorio = int.Parse(Console.ReadLine());
            Random random = new Random();
            Console.WriteLine("\nLos numeros aleatorios son: ");

            for (int i = 0; i < numeroAleatorio; i++)
            {
                int numeroRandom = random.Next(0, 100);
                Console.WriteLine(numeroRandom);

                if ((numeroRandom % 2) == 0)
                {
                    Console.WriteLine("El numero es par");
                    contador++;
                }
                else
                {
                    Console.WriteLine("El numero es impar");
                }
            }

            for (int i = 1; i <= contador; i++)
            {
                total = total * (i * 2);
            }

            Console.WriteLine("\nHa habido " + contador + " numeros pares");
            Console.WriteLine("El producto de los " + contador + " numeros pares es " + total);
        }
    }
}
